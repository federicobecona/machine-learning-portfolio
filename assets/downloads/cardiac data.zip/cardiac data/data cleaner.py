lines = open("cleveland.data", "r", errors='ignore')
writer = open("cleanedCleveland.data", 'w', encoding="cp437", errors='ignore')
header = "id,ccf,age,sex,painloc,painexer,relrest,pncaden,cp,trestbps,htn,chol,smoke,cigs,years,fbs,dm,famhist,restecg,ekgmo,ekgday,ekgyr,dig,prop,nitr,pro,diuretic,proto,thaldur,thaltime,met,thalach,thalrest,tpeakbps,tpeakbpd,dummy,trestbpd,exang,xhypo,oldpeak,slope,rldv5,rldv5e,ca,restckm,exerckm,restef,restwm,exeref,exerwm,thal,thalsev,thalpul,earlobe,cmo,cday,cyr,num,lmt,ladprox,laddist,diag,cxmain,ramus,om1,om2,rcaprox,rcadist,lvx1,lvx2,lvx3,lvx4,lvf,cathef,junk"
writer.write(header+'\n')
info = []
print(lines)
for line in lines:
  lineList = line[:-1].split(" ")
  if'name' not in lineList:
    info.extend(lineList)
  else:
    info.extend(lineList[:-1])
    infoWithMV = ["-1" if x in ["-9","-9.","-9.0"]  else x for x in info]
    infoToWrite = ",".join(infoWithMV)
    writer.write(infoToWrite+'\n')
    info = []
writer.close()
lines.close()
